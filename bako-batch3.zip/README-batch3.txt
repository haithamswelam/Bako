Batch 3 - replaces everything from batch 1, 2 and the Argo fix. Copy into your repo (same folders):
  agent/env/dashboard.py  flow_tab.py  charts.py  obs.py  sli.py
(patch_bootstrap_argo.py: run once from the repo root if you have not yet.)
Restart the dashboard.

Changed
- Number cards: numbers and description only, no small graphs.
- Success ratio ring rebuilt: green / amber / red slices, no cut.
- "Ask Bako to troubleshoot this": the question appears short in the chat, the answer appears under the request ("Bako's answer") and in the chat.
- Bako now thinks in the background: switching pages or refreshing no longer loses the answer.
- New third view "Bako & AI": the Bako and AI flow and what each question cost. The Flow tab (Operator) keeps only Start and Stop.
- How it travelled: names Backend pod or Frontend pod, and the Database for API requests. The database time is still inside the backend time: splitting it needs tracing (next step).
